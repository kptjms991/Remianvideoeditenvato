import { 
  type User, 
  type InsertUser,
  type Template,
  type InsertTemplate,
  type Project,
  type InsertProject,
  type Favorite,
  type InsertFavorite
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Template methods
  getTemplates(params?: { search?: string; category?: string }): Promise<Template[]>;
  getTemplate(id: string): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  
  // Project methods
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  
  // Favorites methods
  getFavorites(): Promise<string[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(templateId: string): Promise<boolean>;
  isFavorite(templateId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private templates: Map<string, Template>;
  private projects: Map<string, Project>;
  private favorites: Map<string, Favorite>;

  constructor() {
    this.users = new Map();
    this.templates = new Map();
    this.projects = new Map();
    this.favorites = new Map();
    
    this.seedTemplates();
  }

  private seedTemplates() {
    const sampleTemplates: InsertTemplate[] = [
      {
        title: "Corporate Product Launch",
        description: "Professional video template for showcasing new products with sleek animations and modern design.",
        thumbnailUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["corporate", "product", "business", "modern"],
        author: "Creative Studio",
        duration: 30,
      },
      {
        title: "Social Media Promo",
        description: "Eye-catching template perfect for Instagram, TikTok, and YouTube shorts with dynamic transitions.",
        thumbnailUrl: "https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["social media", "promo", "instagram", "dynamic"],
        author: "Motion Graphics Pro",
        duration: 15,
      },
      {
        title: "Tech Startup Intro",
        description: "Modern tech-focused intro video with particle effects and futuristic design elements.",
        thumbnailUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["tech", "startup", "modern", "futuristic"],
        author: "Digital Dynamics",
        duration: 20,
      },
      {
        title: "Logo Reveal Animation",
        description: "Elegant logo reveal with smooth animations and customizable colors.",
        thumbnailUrl: "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "graphics",
        tags: ["logo", "animation", "reveal", "branding"],
        author: "Brand Motion",
        duration: 10,
      },
      {
        title: "Event Promotion Video",
        description: "Perfect for concerts, festivals, and special events with vibrant colors and energetic motion.",
        thumbnailUrl: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["event", "concert", "festival", "energetic"],
        author: "Event Media",
        duration: 25,
      },
      {
        title: "Real Estate Showcase",
        description: "Professional property showcase template with elegant transitions and text overlays.",
        thumbnailUrl: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["real estate", "property", "professional", "elegant"],
        author: "Property Vision",
        duration: 35,
      },
      {
        title: "Fitness Motivation Video",
        description: "High-energy template for fitness content with powerful typography and dynamic cuts.",
        thumbnailUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["fitness", "motivation", "sports", "energy"],
        author: "Fitness Media",
        duration: 20,
      },
      {
        title: "Food & Restaurant Promo",
        description: "Appetizing template for restaurants and food brands with mouth-watering visuals.",
        thumbnailUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&h=450&fit=crop",
        previewUrl: "",
        category: "video",
        tags: ["food", "restaurant", "culinary", "delicious"],
        author: "Culinary Creatives",
        duration: 30,
      },
    ];

    sampleTemplates.forEach(template => {
      const id = randomUUID();
      const createdAt = new Date();
      this.templates.set(id, { id, ...template, createdAt });
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Template methods
  async getTemplates(params?: { search?: string; category?: string }): Promise<Template[]> {
    let templates = Array.from(this.templates.values());
    
    if (params?.search) {
      const searchLower = params.search.toLowerCase();
      templates = templates.filter(t => 
        t.title.toLowerCase().includes(searchLower) ||
        t.description?.toLowerCase().includes(searchLower) ||
        t.tags?.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }
    
    if (params?.category && params.category !== 'all') {
      templates = templates.filter(t => t.category === params.category);
    }
    
    return templates.sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const createdAt = new Date();
    const newTemplate: Template = { id, ...template, createdAt };
    this.templates.set(id, newTemplate);
    return newTemplate;
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => 
      new Date(b.updatedAt!).getTime() - new Date(a.updatedAt!).getTime()
    );
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = randomUUID();
    const now = new Date();
    const newProject: Project = { 
      id, 
      ...project, 
      createdAt: now,
      updatedAt: now 
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { 
      ...project, 
      ...updates,
      updatedAt: new Date()
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Favorites methods
  async getFavorites(): Promise<string[]> {
    return Array.from(this.favorites.values()).map(f => f.templateId);
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const id = randomUUID();
    const createdAt = new Date();
    const newFavorite: Favorite = { id, ...favorite, createdAt };
    this.favorites.set(favorite.templateId, newFavorite);
    return newFavorite;
  }

  async removeFavorite(templateId: string): Promise<boolean> {
    return this.favorites.delete(templateId);
  }

  async isFavorite(templateId: string): Promise<boolean> {
    return this.favorites.has(templateId);
  }
}

export const storage = new MemStorage();
