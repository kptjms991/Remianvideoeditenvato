# Video Editor Platform Design Guidelines

## Design Approach

**Selected Approach**: Design System (Professional Creative Tools)
**Primary References**: Adobe Creative Suite, Figma, Canva editing interfaces
**Secondary Inspiration**: Placeit's clean template browsing aesthetic

**Design Philosophy**: Create a professional-grade editing environment that balances powerful functionality with approachable usability. The interface should feel familiar to users of modern creative tools while maintaining clarity in complex workflows.

---

## Layout System

### Application Shell Structure

**Four-Panel Layout (Desktop)**:
- Left Sidebar: Fixed width 320px for template library/asset browser
- Center Canvas: Flexible workspace with 16:9 preview container, centered
- Right Panel: Fixed width 280px for properties and settings
- Bottom Timeline: Fixed height 200px, collapsible to 120px

**Responsive Behavior**:
- Tablets (768px-1024px): Collapsible sidebars with overlay, timeline remains visible
- Mobile: Stack vertically - header nav, canvas preview (simplified), timeline drawer

**Spacing System**: Use Tailwind units of 1, 2, 3, 4, 6, 8, 12, 16, 20 for consistency
- Panel padding: p-4 to p-6
- Component spacing: gap-3 to gap-4 for dense layouts, gap-6 to gap-8 for sections
- Tight controls: space-y-2 or space-y-3
- Section breaks: mb-8 to mb-12

---

## Typography Hierarchy

**Font Families**:
- **Primary (UI)**: "Inter" or "DM Sans" - for interface elements, labels, controls
- **Secondary (Display)**: "Plus Jakarta Sans" or "Outfit" - for headings, template titles
- **Monospace (Technical)**: "JetBrains Mono" - for timecodes, frame numbers

**Type Scale**:
- **Headings**:
  - H1 (Page Titles): text-2xl font-semibold (24px)
  - H2 (Section Headers): text-lg font-semibold (18px)
  - H3 (Panel Titles): text-base font-medium (16px)
  
- **Body**:
  - Primary: text-sm (14px) - main UI text, labels
  - Secondary: text-xs (12px) - helper text, metadata
  - Micro: text-[11px] - timestamps, technical info

- **Interactive Elements**:
  - Buttons: text-sm font-medium
  - Tab Labels: text-sm font-medium
  - Input Fields: text-sm

---

## Component Library

### Navigation & Headers

**Top Navigation Bar**:
- Fixed height h-14
- Contains: Logo (left), Project name/breadcrumb (center-left), Actions (Export, Share, Save - right), Account menu (far right)
- Divided with subtle borders, not blocks

**Left Sidebar (Template Library)**:
- Search bar with icon at top (sticky)
- Category tabs below search
- Scrollable template grid: 2 columns of cards
- Template cards: aspect-ratio-video thumbnail, title (text-sm truncate), author/metadata (text-xs)
- Hover states reveal overlay with "Preview" and "Use Template" actions

**Right Panel (Properties)**:
- Tabbed interface for: Properties, Timeline, Effects, Export
- Collapsible sections (accordion style) with chevron icons
- Form controls grouped with mb-4 spacing
- Input groups use label above, small helper text below

### Canvas & Workspace

**Center Canvas Area**:
- Video preview container: max-w-5xl centered, maintains 16:9 aspect ratio
- Playback controls bar below preview: Play/Pause (center), Scrubber (full width), Time display (left), Frame controls (right)
- Zoom controls (top-right of canvas): 50%, 100%, Fit, 200%
- Canvas background uses subtle grid pattern when zoomed

**Timeline (Bottom Panel)**:
- Layer tracks: Video layers, audio tracks, text/graphics overlays
- Each track: h-12 with toggle visibility, lock, and delete icons
- Playhead: Draggable vertical line with time indicator
- Zoom controls: Horizontal zoom slider (right side)
- Add layer button (+ icon) prominent at top-left of timeline

### Interactive Controls

**Buttons**:
- Primary actions: px-4 py-2 rounded-md font-medium
- Secondary actions: px-3 py-1.5 rounded border
- Icon-only: p-2 rounded hover background
- Blurred background for buttons over images: backdrop-blur-sm bg-opacity-90

**Form Inputs**:
- Text inputs: h-9 px-3 rounded-md border
- Dropdowns: h-9 with chevron-down icon
- Sliders: Custom styled with clear value display
- Number inputs: Include increment/decrement buttons

**Cards (Template Browsing)**:
- Rounded corners: rounded-lg
- Thumbnail: aspect-video with object-cover
- Padding: p-3
- Hover: Subtle scale (scale-105) with smooth transition
- Badge overlays for "New", "Pro", "Featured" (top-right)

**Modals & Overlays**:
- Full-screen overlay: backdrop with backdrop-blur-sm
- Modal content: max-w-2xl to max-w-4xl centered, rounded-xl
- Modal header: pb-4 border-b
- Modal footer: pt-4 border-t with action buttons (right-aligned)

### Data Display

**Template Grid (Sidebar)**:
- Grid: grid-cols-2 gap-3
- Infinite scroll or pagination at bottom
- Loading states: Skeleton cards with pulse animation

**Timeline Clips**:
- Rounded rectangles representing video segments
- Clip labels: Truncated text inside clip
- Resize handles on edges (cursor changes)
- Transition indicators between clips

**Property Panels**:
- Label-value pairs in vertical stack
- Color pickers with swatch preview
- Font selectors with preview text
- Effect toggles with preview thumbnails

---

## Page Layouts

### Main Editor Interface

**Layout**:
```
┌─────────────────────────────────────────────┐
│  Top Navigation (h-14)                      │
├──────┬──────────────────────────┬───────────┤
│ Left │                          │   Right   │
│ Side │   Canvas Preview         │   Props   │
│ bar  │   (centered, 16:9)       │   Panel   │
│(320) │                          │   (280)   │
│      │   Playback Controls      │           │
├──────┴──────────────────────────┴───────────┤
│  Timeline (h-48)                            │
└─────────────────────────────────────────────┘
```

**Browse Mode** (No project open):
- Larger template grid: 3-4 columns in main area
- Featured templates carousel at top
- Filter sidebar (left) with categories, tags, duration ranges
- Sort options (right): Most Popular, Newest, Trending

### Template Preview Modal

- Full-screen takeover with close button (top-right)
- Large video player (center): max-w-4xl
- Template details (below/side): Title, author, description, tags, ratings
- Action bar (bottom): "Use Template" primary, "Bookmark" secondary, "Learn More" tertiary
- Related templates carousel at bottom

---

## Images

**Hero Section**: None - this is a functional tool, not a marketing site

**Template Thumbnails**: Video preview frames from Envato API
- Placement: Template cards throughout browse and sidebar views
- Treatment: Consistent aspect-ratio-video containers
- Loading: Skeleton shimmer before image loads

**Placeholder States**:
- Empty canvas: Centered illustration/icon with "Select a template to start" text
- No search results: Empty state illustration with "No templates found" message

**User Content**:
- Profile avatars: rounded-full w-8 h-8 in navigation
- Custom uploaded assets: Displayed as thumbnails in asset library panel

---

## Animations & Interactions

**Minimal Motion Approach**:
- Panel transitions: 200ms ease-in-out when toggling sidebars
- Hover states: Subtle scale or opacity changes (100-150ms)
- Loading states: Pulse animation on skeletons
- No decorative scroll animations
- Timeline scrubbing: Smooth, immediate feedback

**Micro-interactions**:
- Button clicks: Brief scale-95 on active state
- Dropdown opening: Slide-down with fade (150ms)
- Toast notifications: Slide in from top-right, auto-dismiss after 3s
- Drag indicators: Cursor changes, drop zones highlight

---

## Accessibility Standards

- Keyboard navigation: Full support for all controls, visible focus rings
- ARIA labels: All icon buttons and interactive elements
- Color contrast: Meets WCAG AA standards minimum
- Text inputs: Consistent h-9 height, clear focus states
- Screen reader: Meaningful labels for timeline and canvas controls
- Form inputs: Labels always visible, not placeholder-only