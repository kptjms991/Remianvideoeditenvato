import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  thumbnailUrl: text("thumbnail_url").notNull(),
  previewUrl: text("preview_url"),
  category: text("category").notNull(),
  tags: text("tags").array(),
  author: text("author"),
  duration: integer("duration"),
  envatoId: text("envato_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
});

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  templateId: varchar("template_id"),
  duration: integer("duration").default(30),
  resolution: text("resolution").default("1920x1080"),
  fps: integer("fps").default(30),
  layers: jsonb("layers").notNull().default('[]'),
  settings: jsonb("settings").notNull().default('{}'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export const favorites = pgTable("favorites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  templateId: varchar("template_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;

// Client-side types for editor state
export type LayerType = 'video' | 'audio' | 'text' | 'image' | 'shape';

export interface TimelineLayer {
  id: string;
  type: LayerType;
  name: string;
  startTime: number;
  duration: number;
  visible: boolean;
  locked: boolean;
  properties: Record<string, any>;
}

export interface TextLayerProperties {
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: number;
  color: string;
  align: 'left' | 'center' | 'right';
  position: { x: number; y: number };
  rotation: number;
  opacity: number;
  animation?: string;
}

export interface VideoLayerProperties {
  url: string;
  volume: number;
  playbackRate: number;
  opacity: number;
  position: { x: number; y: number };
  scale: number;
  rotation: number;
}

export interface AudioLayerProperties {
  url: string;
  volume: number;
  fadeIn: number;
  fadeOut: number;
}

export interface Effect {
  id: string;
  name: string;
  type: 'transition' | 'filter' | 'animation';
  properties: Record<string, any>;
}

export interface ProjectSettings {
  backgroundColor: string;
  audioTracks: AudioLayerProperties[];
  exportFormat: 'mp4' | 'webm' | 'mov';
  quality: 'low' | 'medium' | 'high' | 'ultra';
}
