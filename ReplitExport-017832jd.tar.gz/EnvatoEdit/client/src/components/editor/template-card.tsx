import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Play, Clock } from "lucide-react";
import type { Template } from "@shared/schema";

interface TemplateCardProps {
  template: Template;
  isFavorite: boolean;
  onClick: () => void;
  onUse: () => void;
  onToggleFavorite: () => void;
}

export function TemplateCard({ 
  template, 
  isFavorite, 
  onClick, 
  onUse,
  onToggleFavorite 
}: TemplateCardProps) {
  return (
    <Card 
      className="overflow-hidden cursor-pointer hover-elevate group relative"
      onClick={onClick}
      data-testid={`card-template-${template.id}`}
    >
      <div className="relative aspect-video bg-muted overflow-hidden">
        <img
          src={template.thumbnailUrl}
          alt={template.title}
          className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
        />
        
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-200 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="secondary"
              onClick={(e) => {
                e.stopPropagation();
                onClick();
              }}
              className="gap-2 backdrop-blur-sm bg-background/90"
              data-testid={`button-preview-${template.id}`}
            >
              <Play className="w-3 h-3" />
              Preview
            </Button>
            <Button 
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onUse();
              }}
              className="gap-2"
              data-testid={`button-use-${template.id}`}
            >
              Use Template
            </Button>
          </div>
        </div>

        <Button
          size="icon"
          variant="ghost"
          className="absolute top-2 right-2 w-8 h-8 backdrop-blur-sm bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
          data-testid={`button-favorite-${template.id}`}
        >
          <Heart 
            className={`w-4 h-4 ${isFavorite ? 'fill-destructive text-destructive' : ''}`} 
          />
        </Button>

        {template.tags && template.tags[0] && (
          <Badge 
            variant="secondary" 
            className="absolute top-2 left-2 text-xs backdrop-blur-sm bg-background/90"
          >
            {template.tags[0]}
          </Badge>
        )}
      </div>

      <div className="p-3 space-y-1">
        <h3 
          className="text-sm font-medium text-foreground line-clamp-1"
          data-testid={`text-template-title-${template.id}`}
        >
          {template.title}
        </h3>
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {template.author || "Unknown"}
          </p>
          {template.duration && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              {template.duration}s
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
