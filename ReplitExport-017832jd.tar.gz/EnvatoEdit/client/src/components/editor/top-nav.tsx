import { Button } from "@/components/ui/button";
import { 
  Save, 
  Download, 
  Share2, 
  Settings, 
  User,
  ChevronDown,
  Folder
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Project } from "@shared/schema";

interface TopNavProps {
  project: Project | null;
  onSave: () => void;
  onExport: () => void;
}

export function TopNav({ project, onSave, onExport }: TopNavProps) {
  return (
    <header className="h-14 border-b flex items-center justify-between px-4 gap-4 bg-background">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-display font-bold text-sm">VE</span>
          </div>
          <span className="font-display font-semibold text-lg">Video Editor</span>
        </div>
        
        <div className="h-6 w-px bg-border" />
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" data-testid="button-project-menu" className="gap-2">
              <Folder className="w-4 h-4" />
              <span className="text-sm font-medium">
                {project?.name || "New Project"}
              </span>
              <ChevronDown className="w-3 h-3 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem data-testid="menu-new-project">
              New Project
            </DropdownMenuItem>
            <DropdownMenuItem data-testid="menu-open-project">
              Open Project
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="menu-project-settings">
              Project Settings
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-2">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onSave}
          data-testid="button-save"
          className="gap-2"
        >
          <Save className="w-4 h-4" />
          <span className="text-sm">Save</span>
        </Button>
        
        <Button 
          variant="ghost" 
          size="sm"
          data-testid="button-share"
          className="gap-2"
        >
          <Share2 className="w-4 h-4" />
          <span className="text-sm">Share</span>
        </Button>
        
        <Button 
          variant="default" 
          size="sm"
          onClick={onExport}
          data-testid="button-export"
          className="gap-2"
        >
          <Download className="w-4 h-4" />
          <span className="text-sm font-medium">Export</span>
        </Button>

        <div className="h-6 w-px bg-border mx-1" />

        <Button 
          variant="ghost" 
          size="icon"
          data-testid="button-settings"
        >
          <Settings className="w-4 h-4" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon"
              data-testid="button-account"
            >
              <User className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem data-testid="menu-profile">Profile</DropdownMenuItem>
            <DropdownMenuItem data-testid="menu-preferences">Preferences</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem data-testid="menu-logout">Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
