import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import { 
  Plus, 
  Video, 
  Music, 
  Type, 
  Image as ImageIcon,
  Maximize2,
  Minimize2
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TimelineTrack } from "./timeline-track";
import type { Project, TimelineLayer } from "@shared/schema";

interface TimelineProps {
  project: Project | null;
  currentTime: number;
  selectedLayer: TimelineLayer | null;
  onLayerSelect: (layer: TimelineLayer | null) => void;
  onTimeChange: (time: number) => void;
  onLayersChange: (layers: TimelineLayer[]) => void;
}

export function Timeline({ 
  project, 
  currentTime, 
  selectedLayer,
  onLayerSelect,
  onTimeChange,
  onLayersChange 
}: TimelineProps) {
  const [zoom, setZoom] = useState(100);
  const [isExpanded, setIsExpanded] = useState(true);

  const layers: TimelineLayer[] = (project?.layers as TimelineLayer[]) || [];
  const duration = project?.duration || 30;

  const handleAddLayer = (type: TimelineLayer['type']) => {
    const newLayer: TimelineLayer = {
      id: `layer-${Date.now()}`,
      type,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} Layer`,
      startTime: 0,
      duration: 5,
      visible: true,
      locked: false,
      properties: {},
    };
    onLayersChange([...layers, newLayer]);
  };

  return (
    <div className={`border-t bg-card transition-all ${isExpanded ? 'h-48' : 'h-12'}`}>
      <div className="h-12 border-b flex items-center justify-between px-4 gap-3">
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setIsExpanded(!isExpanded)}
            data-testid="button-toggle-timeline"
            className="h-8 w-8"
          >
            {isExpanded ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </Button>

          <span className="text-sm font-medium">Timeline</span>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                size="sm" 
                variant="default"
                className="h-8 gap-1.5"
                data-testid="button-add-layer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Layer
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => handleAddLayer('video')} data-testid="menu-add-video">
                <Video className="w-4 h-4 mr-2" />
                Video Layer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleAddLayer('audio')} data-testid="menu-add-audio">
                <Music className="w-4 h-4 mr-2" />
                Audio Layer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleAddLayer('text')} data-testid="menu-add-text">
                <Type className="w-4 h-4 mr-2" />
                Text Layer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleAddLayer('image')} data-testid="menu-add-image">
                <ImageIcon className="w-4 h-4 mr-2" />
                Image Layer
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Zoom</span>
          <Slider
            value={[zoom]}
            min={50}
            max={200}
            step={10}
            onValueChange={([value]) => setZoom(value)}
            className="w-24"
            data-testid="slider-timeline-zoom"
          />
          <span className="text-xs text-muted-foreground font-mono min-w-[40px]">
            {zoom}%
          </span>
        </div>
      </div>

      {isExpanded && (
        <ScrollArea className="h-[calc(100%-3rem)]">
          <div className="relative">
            {layers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <Plus className="w-6 h-6 text-primary" />
                </div>
                <p className="text-sm font-medium text-foreground">No Layers Yet</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Click "Add Layer" to start building your video
                </p>
              </div>
            ) : (
              <div className="space-y-px">
                {layers.map((layer) => (
                  <TimelineTrack
                    key={layer.id}
                    layer={layer}
                    duration={duration}
                    zoom={zoom}
                    currentTime={currentTime}
                    isSelected={selectedLayer?.id === layer.id}
                    onSelect={() => onLayerSelect(layer)}
                    onUpdate={(updatedLayer) => {
                      const newLayers = layers.map(l => 
                        l.id === updatedLayer.id ? updatedLayer : l
                      );
                      onLayersChange(newLayers);
                    }}
                    onDelete={() => {
                      const newLayers = layers.filter(l => l.id !== layer.id);
                      onLayersChange(newLayers);
                      if (selectedLayer?.id === layer.id) {
                        onLayerSelect(null);
                      }
                    }}
                  />
                ))}
              </div>
            )}

            {layers.length > 0 && (
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-primary pointer-events-none"
                style={{ 
                  left: `${(currentTime / duration) * 100}%`,
                  transform: 'translateX(-1px)'
                }}
              >
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-primary rounded-full" />
              </div>
            )}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
