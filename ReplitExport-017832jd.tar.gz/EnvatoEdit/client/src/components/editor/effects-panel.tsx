import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  Sparkles, 
  Zap, 
  Wind,
  Palette,
  Blend,
  ArrowRightLeft,
  X
} from "lucide-react";
import type { TimelineLayer, Effect } from "@shared/schema";

interface EffectsPanelProps {
  layer: TimelineLayer | null;
  onApplyEffect: (effect: Effect) => void;
}

const effectsLibrary = [
  {
    id: 'fade-in',
    name: 'Fade In',
    type: 'transition' as const,
    icon: Wind,
    description: 'Smooth fade in transition',
  },
  {
    id: 'fade-out',
    name: 'Fade Out',
    type: 'transition' as const,
    icon: Wind,
    description: 'Smooth fade out transition',
  },
  {
    id: 'slide-left',
    name: 'Slide Left',
    type: 'transition' as const,
    icon: ArrowRightLeft,
    description: 'Slide in from left',
  },
  {
    id: 'slide-right',
    name: 'Slide Right',
    type: 'transition' as const,
    icon: ArrowRightLeft,
    description: 'Slide in from right',
  },
  {
    id: 'blur',
    name: 'Blur',
    type: 'filter' as const,
    icon: Blend,
    description: 'Add blur effect',
  },
  {
    id: 'grayscale',
    name: 'Grayscale',
    type: 'filter' as const,
    icon: Palette,
    description: 'Convert to black and white',
  },
  {
    id: 'glow',
    name: 'Glow',
    type: 'filter' as const,
    icon: Sparkles,
    description: 'Add glowing effect',
  },
  {
    id: 'zoom-in',
    name: 'Zoom In',
    type: 'animation' as const,
    icon: Zap,
    description: 'Animated zoom in',
  },
];

export function EffectsPanel({ layer, onApplyEffect }: EffectsPanelProps) {
  const [appliedEffects, setAppliedEffects] = useState<Effect[]>([]);
  const { toast } = useToast();

  if (!layer) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Sparkles className="w-12 h-12 text-muted-foreground mb-3" />
        <p className="text-sm font-medium text-foreground">No Layer Selected</p>
        <p className="text-xs text-muted-foreground mt-1 px-4">
          Select a layer to apply effects
        </p>
      </div>
    );
  }

  const handleApplyEffect = (effect: Effect) => {
    setAppliedEffects([...appliedEffects, effect]);
    onApplyEffect(effect);
    toast({
      title: "Effect Applied",
      description: `${effect.name} has been applied to ${layer.name}`,
    });
  };

  const handleRemoveEffect = (effectId: string) => {
    setAppliedEffects(appliedEffects.filter(e => e.id !== effectId));
    toast({
      title: "Effect Removed",
      description: "Effect has been removed from the layer",
    });
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold mb-1">Effects Library</h3>
        <p className="text-xs text-muted-foreground">
          Click to apply effects to {layer.name}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-2">
        {effectsLibrary.map((effect) => {
          const Icon = effect.icon;
          return (
            <Button
              key={effect.id}
              variant="outline"
              className="h-auto p-3 justify-start hover-elevate"
              onClick={() => handleApplyEffect({
                id: effect.id,
                name: effect.name,
                type: effect.type,
                properties: {},
              })}
              data-testid={`button-effect-${effect.id}`}
            >
              <div className="flex items-start gap-3 w-full">
                <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 text-left">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-medium">{effect.name}</span>
                    <Badge variant="secondary" className="text-[10px] h-4 px-1.5">
                      {effect.type}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {effect.description}
                  </p>
                </div>
              </div>
            </Button>
          );
        })}
      </div>

      <div className="pt-4 border-t">
        <h4 className="text-xs font-semibold mb-2">Applied Effects</h4>
        {appliedEffects.length === 0 ? (
          <div className="text-xs text-muted-foreground">
            No effects applied yet
          </div>
        ) : (
          <div className="space-y-2">
            {appliedEffects.map((effect) => (
              <div
                key={effect.id}
                className="flex items-center justify-between p-2 rounded-md bg-muted/50"
              >
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-[10px] h-4 px-1.5">
                    {effect.type}
                  </Badge>
                  <span className="text-xs font-medium">{effect.name}</span>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6"
                  onClick={() => handleRemoveEffect(effect.id)}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
