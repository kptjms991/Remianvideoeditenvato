import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { Download, FileVideo, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Project, ProjectSettings } from "@shared/schema";

interface ExportPanelProps {
  project: Project | null;
  onExport: (settings: Partial<ProjectSettings>) => void;
}

export function ExportPanel({ project, onExport }: ExportPanelProps) {
  const [format, setFormat] = useState<'mp4' | 'webm' | 'mov'>('mp4');
  const [quality, setQuality] = useState<'low' | 'medium' | 'high' | 'ultra'>('high');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const { toast } = useToast();

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <FileVideo className="w-12 h-12 text-muted-foreground mb-3" />
        <p className="text-sm font-medium text-foreground">No Project</p>
        <p className="text-xs text-muted-foreground mt-1 px-4">
          Create or open a project to export
        </p>
      </div>
    );
  }

  const handleExport = () => {
    setIsExporting(true);
    setExportProgress(0);

    const settings = {
      exportFormat: format,
      quality,
    };

    // Simulate export progress
    const interval = setInterval(() => {
      setExportProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsExporting(false);
          toast({
            title: "Export Complete!",
            description: `Your video has been exported as ${format.toUpperCase()}`,
          });
          onExport(settings);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  const estimatedSize = quality === 'ultra' ? '~50 MB' : 
                        quality === 'high' ? '~25 MB' : 
                        quality === 'medium' ? '~15 MB' : '~10 MB';

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <FileVideo className="w-4 h-4" />
          Export Settings
        </h3>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="export-format" className="text-xs">Format</Label>
            <Select value={format} onValueChange={(v: any) => setFormat(v)}>
              <SelectTrigger id="export-format" className="h-9 text-sm" data-testid="select-export-format">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mp4">MP4 (Recommended)</SelectItem>
                <SelectItem value="webm">WebM</SelectItem>
                <SelectItem value="mov">MOV</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              MP4 is compatible with most devices and platforms
            </p>
          </div>

          <div className="space-y-3">
            <Label className="text-xs">Quality</Label>
            <RadioGroup value={quality} onValueChange={(v: any) => setQuality(v)}>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="low" id="quality-low" data-testid="radio-quality-low" />
                  <Label htmlFor="quality-low" className="text-sm font-normal cursor-pointer">
                    Low (720p)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="medium" id="quality-medium" data-testid="radio-quality-medium" />
                  <Label htmlFor="quality-medium" className="text-sm font-normal cursor-pointer">
                    Medium (1080p)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="high" id="quality-high" data-testid="radio-quality-high" />
                  <Label htmlFor="quality-high" className="text-sm font-normal cursor-pointer">
                    High (1080p 60fps)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="ultra" id="quality-ultra" data-testid="radio-quality-ultra" />
                  <Label htmlFor="quality-ultra" className="text-sm font-normal cursor-pointer">
                    Ultra (4K)
                  </Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          <div className="pt-4 border-t space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Resolution</span>
              <span className="font-mono">{project.resolution}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Frame Rate</span>
              <span className="font-mono">{project.fps} fps</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Duration</span>
              <span className="font-mono">{project.duration}s</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Estimated Size</span>
              <span className="font-mono">{estimatedSize}</span>
            </div>
          </div>
        </div>
      </div>

      {isExporting && (
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Exporting...</span>
            <span className="font-mono">{exportProgress}%</span>
          </div>
          <Progress value={exportProgress} className="h-2" />
        </div>
      )}

      <Button 
        className="w-full gap-2"
        size="default"
        onClick={handleExport}
        disabled={isExporting}
        data-testid="button-export-video"
      >
        {isExporting ? (
          <>
            <Download className="w-4 h-4 animate-pulse-subtle" />
            Exporting...
          </>
        ) : exportProgress === 100 ? (
          <>
            <CheckCircle2 className="w-4 h-4" />
            Export Complete
          </>
        ) : (
          <>
            <Download className="w-4 h-4" />
            Export Video
          </>
        )}
      </Button>

      <div className="pt-2 border-t">
        <p className="text-xs text-muted-foreground">
          Export will render your video with all applied effects and transitions.
        </p>
      </div>
    </div>
  );
}
