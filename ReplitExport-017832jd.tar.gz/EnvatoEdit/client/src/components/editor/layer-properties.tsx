import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Type, Move, RotateCw, Sparkles } from "lucide-react";
import type { TimelineLayer, TextLayerProperties } from "@shared/schema";

interface LayerPropertiesProps {
  layer: TimelineLayer;
  onUpdate: (layer: TimelineLayer) => void;
}

export function LayerProperties({ layer, onUpdate }: LayerPropertiesProps) {
  const updateProperty = (key: string, value: any) => {
    onUpdate({
      ...layer,
      properties: {
        ...layer.properties,
        [key]: value,
      },
    });
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
          <Type className="w-4 h-4" />
          Layer Settings
        </h3>
        
        <div className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="layer-name" className="text-xs">Layer Name</Label>
            <Input
              id="layer-name"
              value={layer.name}
              onChange={(e) => onUpdate({ ...layer, name: e.target.value })}
              className="h-8 text-sm"
              data-testid="input-layer-name"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="start-time" className="text-xs">Start (s)</Label>
              <Input
                id="start-time"
                type="number"
                value={layer.startTime}
                onChange={(e) => onUpdate({ ...layer, startTime: parseFloat(e.target.value) })}
                className="h-8 text-sm"
                step="0.1"
                data-testid="input-start-time"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration" className="text-xs">Duration (s)</Label>
              <Input
                id="duration"
                type="number"
                value={layer.duration}
                onChange={(e) => onUpdate({ ...layer, duration: parseFloat(e.target.value) })}
                className="h-8 text-sm"
                step="0.1"
                data-testid="input-duration"
              />
            </div>
          </div>
        </div>
      </div>

      {layer.type === 'text' && (
        <Accordion type="single" collapsible defaultValue="text">
          <AccordionItem value="text">
            <AccordionTrigger className="text-sm font-semibold">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4" />
                Text Properties
              </div>
            </AccordionTrigger>
            <AccordionContent className="space-y-3 pt-3">
              <div className="space-y-2">
                <Label htmlFor="text-content" className="text-xs">Text Content</Label>
                <Input
                  id="text-content"
                  value={(layer.properties as TextLayerProperties).text || ''}
                  onChange={(e) => updateProperty('text', e.target.value)}
                  className="h-8 text-sm"
                  placeholder="Enter text..."
                  data-testid="input-text-content"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="font-family" className="text-xs">Font Family</Label>
                <Select
                  value={(layer.properties as TextLayerProperties).fontFamily || 'Inter'}
                  onValueChange={(value) => updateProperty('fontFamily', value)}
                >
                  <SelectTrigger className="h-8 text-sm" data-testid="select-font-family">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Inter">Inter</SelectItem>
                    <SelectItem value="Plus Jakarta Sans">Plus Jakarta Sans</SelectItem>
                    <SelectItem value="JetBrains Mono">JetBrains Mono</SelectItem>
                    <SelectItem value="Arial">Arial</SelectItem>
                    <SelectItem value="Georgia">Georgia</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="font-size" className="text-xs">Size</Label>
                  <Input
                    id="font-size"
                    type="number"
                    value={(layer.properties as TextLayerProperties).fontSize || 24}
                    onChange={(e) => updateProperty('fontSize', parseInt(e.target.value))}
                    className="h-8 text-sm"
                    data-testid="input-font-size"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="text-color" className="text-xs">Color</Label>
                  <Input
                    id="text-color"
                    type="color"
                    value={(layer.properties as TextLayerProperties).color || '#ffffff'}
                    onChange={(e) => updateProperty('color', e.target.value)}
                    className="h-8"
                    data-testid="input-text-color"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="text-align" className="text-xs">Alignment</Label>
                <Select
                  value={(layer.properties as TextLayerProperties).align || 'left'}
                  onValueChange={(value) => updateProperty('align', value)}
                >
                  <SelectTrigger className="h-8 text-sm" data-testid="select-text-align">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="left">Left</SelectItem>
                    <SelectItem value="center">Center</SelectItem>
                    <SelectItem value="right">Right</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="transform">
            <AccordionTrigger className="text-sm font-semibold">
              <div className="flex items-center gap-2">
                <Move className="w-4 h-4" />
                Transform
              </div>
            </AccordionTrigger>
            <AccordionContent className="space-y-3 pt-3">
              <div className="space-y-2">
                <Label className="text-xs">Opacity</Label>
                <Slider
                  value={[(layer.properties as TextLayerProperties).opacity || 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={([value]) => updateProperty('opacity', value)}
                  data-testid="slider-opacity"
                />
                <div className="text-xs text-muted-foreground text-right">
                  {(layer.properties as TextLayerProperties).opacity || 100}%
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Rotation</Label>
                <Slider
                  value={[(layer.properties as TextLayerProperties).rotation || 0]}
                  min={0}
                  max={360}
                  step={1}
                  onValueChange={([value]) => updateProperty('rotation', value)}
                  data-testid="slider-rotation"
                />
                <div className="text-xs text-muted-foreground text-right">
                  {(layer.properties as TextLayerProperties).rotation || 0}°
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      )}

      {(layer.type === 'video' || layer.type === 'image') && (
        <Accordion type="single" collapsible defaultValue="transform">
          <AccordionItem value="transform">
            <AccordionTrigger className="text-sm font-semibold">
              <div className="flex items-center gap-2">
                <Move className="w-4 h-4" />
                Transform
              </div>
            </AccordionTrigger>
            <AccordionContent className="space-y-3 pt-3">
              <div className="space-y-2">
                <Label className="text-xs">Scale</Label>
                <Slider
                  value={[layer.properties.scale || 100]}
                  min={10}
                  max={200}
                  step={1}
                  onValueChange={([value]) => updateProperty('scale', value)}
                  data-testid="slider-scale"
                />
                <div className="text-xs text-muted-foreground text-right">
                  {layer.properties.scale || 100}%
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Opacity</Label>
                <Slider
                  value={[layer.properties.opacity || 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={([value]) => updateProperty('opacity', value)}
                  data-testid="slider-opacity"
                />
                <div className="text-xs text-muted-foreground text-right">
                  {layer.properties.opacity || 100}%
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">Rotation</Label>
                <Slider
                  value={[layer.properties.rotation || 0]}
                  min={0}
                  max={360}
                  step={1}
                  onValueChange={([value]) => updateProperty('rotation', value)}
                  data-testid="slider-rotation"
                />
                <div className="text-xs text-muted-foreground text-right">
                  {layer.properties.rotation || 0}°
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      )}
    </div>
  );
}
