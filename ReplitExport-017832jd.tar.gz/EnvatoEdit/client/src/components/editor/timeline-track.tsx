import { Button } from "@/components/ui/button";
import { 
  Eye, 
  EyeOff, 
  Lock, 
  Unlock, 
  Trash2,
  Video,
  Music,
  Type,
  Image as ImageIcon,
  Square
} from "lucide-react";
import type { TimelineLayer } from "@shared/schema";

interface TimelineTrackProps {
  layer: TimelineLayer;
  duration: number;
  zoom: number;
  currentTime: number;
  isSelected: boolean;
  onSelect: () => void;
  onUpdate: (layer: TimelineLayer) => void;
  onDelete: () => void;
}

const layerIcons = {
  video: Video,
  audio: Music,
  text: Type,
  image: ImageIcon,
  shape: Square,
};

const layerColors = {
  video: 'bg-blue-500/20 border-blue-500/40',
  audio: 'bg-green-500/20 border-green-500/40',
  text: 'bg-purple-500/20 border-purple-500/40',
  image: 'bg-orange-500/20 border-orange-500/40',
  shape: 'bg-pink-500/20 border-pink-500/40',
};

export function TimelineTrack({ 
  layer, 
  duration,
  zoom,
  currentTime,
  isSelected, 
  onSelect,
  onUpdate,
  onDelete 
}: TimelineTrackProps) {
  const Icon = layerIcons[layer.type];
  const clipWidth = (layer.duration / duration) * 100;
  const clipLeft = (layer.startTime / duration) * 100;

  return (
    <div 
      className={`h-12 flex items-center border-b hover-elevate ${
        isSelected ? 'bg-accent' : 'bg-card'
      }`}
      onClick={onSelect}
      data-testid={`track-${layer.id}`}
    >
      <div className="w-48 flex items-center gap-2 px-3 border-r">
        <Icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
        <span className="text-xs font-medium truncate flex-1" data-testid={`text-layer-name-${layer.id}`}>
          {layer.name}
        </span>
        
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6"
            onClick={(e) => {
              e.stopPropagation();
              onUpdate({ ...layer, visible: !layer.visible });
            }}
            data-testid={`button-toggle-visibility-${layer.id}`}
          >
            {layer.visible ? (
              <Eye className="w-3 h-3" />
            ) : (
              <EyeOff className="w-3 h-3" />
            )}
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6"
            onClick={(e) => {
              e.stopPropagation();
              onUpdate({ ...layer, locked: !layer.locked });
            }}
            data-testid={`button-toggle-lock-${layer.id}`}
          >
            {layer.locked ? (
              <Lock className="w-3 h-3" />
            ) : (
              <Unlock className="w-3 h-3" />
            )}
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-6 w-6 hover:text-destructive"
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            data-testid={`button-delete-${layer.id}`}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <div className="flex-1 relative h-full">
        <div
          className={`absolute h-8 top-1/2 -translate-y-1/2 rounded border ${
            layerColors[layer.type]
          } ${isSelected ? 'ring-2 ring-primary' : ''}`}
          style={{
            left: `${clipLeft}%`,
            width: `${clipWidth}%`,
            minWidth: '40px'
          }}
        >
          <div className="px-2 h-full flex items-center">
            <span className="text-xs font-medium truncate">
              {layer.name}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
