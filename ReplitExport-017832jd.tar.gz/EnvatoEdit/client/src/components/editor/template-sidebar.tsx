import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Heart, Video } from "lucide-react";
import { TemplateCard } from "./template-card";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Template } from "@shared/schema";

interface TemplateSidebarProps {
  onTemplateClick: (template: Template) => void;
  onUseTemplate: (template: Template) => void;
}

export function TemplateSidebar({ onTemplateClick, onUseTemplate }: TemplateSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [category, setCategory] = useState("all");
  const { toast } = useToast();

  const { data: templates, isLoading } = useQuery<Template[]>({
    queryKey: ["/api/templates", { search: searchQuery, category }],
  });

  const { data: favorites = [] } = useQuery<string[]>({
    queryKey: ["/api/favorites"],
  });

  const addFavoriteMutation = useMutation({
    mutationFn: async (templateId: string) => {
      return await apiRequest("POST", "/api/favorites", { templateId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({
        title: "Added to Favorites",
        description: "Template has been added to your favorites.",
      });
    },
  });

  const removeFavoriteMutation = useMutation({
    mutationFn: async (templateId: string) => {
      return await apiRequest("DELETE", `/api/favorites/${templateId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({
        title: "Removed from Favorites",
        description: "Template has been removed from your favorites.",
      });
    },
  });

  const handleToggleFavorite = (templateId: string, isFavorite: boolean) => {
    if (isFavorite) {
      removeFavoriteMutation.mutate(templateId);
    } else {
      addFavoriteMutation.mutate(templateId);
    }
  };

  const filteredTemplates = templates || [];

  return (
    <aside className="w-80 border-r bg-sidebar flex flex-col">
      <div className="p-4 border-b border-sidebar-border space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9 bg-background"
            data-testid="input-search-templates"
          />
        </div>

        <Tabs value={category} onValueChange={setCategory}>
          <TabsList className="w-full grid grid-cols-3 h-9">
            <TabsTrigger value="all" className="text-xs" data-testid="tab-all">
              All
            </TabsTrigger>
            <TabsTrigger value="video" className="text-xs" data-testid="tab-video">
              Video
            </TabsTrigger>
            <TabsTrigger value="graphics" className="text-xs" data-testid="tab-graphics">
              Graphics
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-3">
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <div className="aspect-video bg-muted rounded-md animate-pulse" />
                  <div className="h-4 bg-muted rounded animate-pulse w-3/4" />
                  <div className="h-3 bg-muted rounded animate-pulse w-1/2" />
                </div>
              ))}
            </div>
          ) : filteredTemplates.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Video className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="text-sm font-medium text-foreground">No templates found</p>
              <p className="text-xs text-muted-foreground mt-1">
                Try adjusting your search or filters
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {filteredTemplates.map((template) => (
                <TemplateCard
                  key={template.id}
                  template={template}
                  isFavorite={favorites.includes(template.id)}
                  onClick={() => onTemplateClick(template)}
                  onUse={() => onUseTemplate(template)}
                  onToggleFavorite={() => handleToggleFavorite(template.id, favorites.includes(template.id))}
                />
              ))}
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-3 border-t border-sidebar-border">
        <Button 
          variant="ghost" 
          size="sm" 
          className="w-full gap-2 justify-start"
          data-testid="button-view-favorites"
        >
          <Heart className="w-4 h-4" />
          <span className="text-sm">My Favorites</span>
          <Badge variant="secondary" className="ml-auto text-xs">
            {favorites.length}
          </Badge>
        </Button>
      </div>
    </aside>
  );
}
