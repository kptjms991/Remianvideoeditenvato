import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Settings2, Layers, Sparkles, Download } from "lucide-react";
import { LayerProperties } from "./layer-properties";
import { EffectsPanel } from "./effects-panel";
import { ExportPanel } from "./export-panel";
import type { Project, TimelineLayer } from "@shared/schema";

interface PropertiesPanelProps {
  project: Project | null;
  selectedLayer: TimelineLayer | null;
  onLayerUpdate: (layer: TimelineLayer) => void;
  onProjectUpdate: (project: Partial<Project>) => void;
}

export function PropertiesPanel({ 
  project, 
  selectedLayer, 
  onLayerUpdate,
  onProjectUpdate 
}: PropertiesPanelProps) {
  return (
    <aside className="w-72 border-l bg-card flex flex-col">
      <Tabs defaultValue="properties" className="flex flex-col h-full">
        <div className="border-b px-3 py-2">
          <TabsList className="w-full grid grid-cols-3 h-9">
            <TabsTrigger value="properties" className="text-xs gap-1.5" data-testid="tab-properties">
              <Settings2 className="w-3.5 h-3.5" />
              Props
            </TabsTrigger>
            <TabsTrigger value="effects" className="text-xs gap-1.5" data-testid="tab-effects">
              <Sparkles className="w-3.5 h-3.5" />
              Effects
            </TabsTrigger>
            <TabsTrigger value="export" className="text-xs gap-1.5" data-testid="tab-export">
              <Download className="w-3.5 h-3.5" />
              Export
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="flex-1">
          <TabsContent value="properties" className="m-0 p-4 space-y-4">
            {selectedLayer ? (
              <LayerProperties 
                layer={selectedLayer} 
                onUpdate={onLayerUpdate}
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Layers className="w-12 h-12 text-muted-foreground mb-3" />
                <p className="text-sm font-medium text-foreground">No Layer Selected</p>
                <p className="text-xs text-muted-foreground mt-1 px-4">
                  Select a layer from the timeline to edit its properties
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="effects" className="m-0 p-4 space-y-4">
            <EffectsPanel 
              layer={selectedLayer}
              onApplyEffect={(effect) => {}}
            />
          </TabsContent>

          <TabsContent value="export" className="m-0 p-4 space-y-4">
            <ExportPanel 
              project={project}
              onExport={(settings) => {}}
            />
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </aside>
  );
}
