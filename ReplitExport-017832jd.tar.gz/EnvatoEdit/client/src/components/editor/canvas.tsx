import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward,
  ZoomIn,
  ZoomOut,
  Maximize2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Project } from "@shared/schema";

interface CanvasProps {
  project: Project | null;
  currentTime: number;
  zoom: number;
  isPlaying: boolean;
  onZoomChange: (zoom: number) => void;
  onPlayPause: () => void;
  onTimeChange: (time: number) => void;
}

export function Canvas({ 
  project, 
  currentTime, 
  zoom, 
  isPlaying,
  onZoomChange,
  onPlayPause,
  onTimeChange 
}: CanvasProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex-1 flex flex-col bg-background">
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-5xl">
          {project ? (
            <div className="relative bg-black rounded-lg overflow-hidden shadow-lg aspect-video">
              <div className="absolute inset-0 flex items-center justify-center text-white/50 text-sm">
                <div className="text-center space-y-2">
                  <div className="text-6xl font-mono font-medium">
                    {formatTime(currentTime)}
                  </div>
                  <div className="text-muted-foreground">
                    Canvas Preview - {project.resolution} @ {project.fps}fps
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="aspect-video rounded-lg border-2 border-dashed border-border bg-muted/20 flex items-center justify-center">
              <div className="text-center space-y-3 p-8">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <Play className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-display font-semibold text-foreground">
                    Start Your Project
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Select a template from the sidebar or create a new project
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="absolute top-4 right-4 flex items-center gap-2">
            <Select value={zoom.toString()} onValueChange={(v) => onZoomChange(Number(v))}>
              <SelectTrigger className="w-24 h-8 text-xs bg-background/90 backdrop-blur-sm" data-testid="select-zoom">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="50">50%</SelectItem>
                <SelectItem value="75">75%</SelectItem>
                <SelectItem value="100">100%</SelectItem>
                <SelectItem value="150">150%</SelectItem>
                <SelectItem value="200">200%</SelectItem>
              </SelectContent>
            </Select>
            
            <Button 
              size="icon" 
              variant="secondary"
              className="h-8 w-8 bg-background/90 backdrop-blur-sm"
              data-testid="button-fit-canvas"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="border-t p-4 bg-card">
        <div className="max-w-5xl mx-auto space-y-3">
          <div className="flex items-center gap-3">
            <Button 
              size="icon" 
              variant="ghost"
              onClick={() => onTimeChange(0)}
              data-testid="button-skip-back"
            >
              <SkipBack className="w-4 h-4" />
            </Button>

            <Button 
              size="icon"
              onClick={onPlayPause}
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </Button>

            <Button 
              size="icon" 
              variant="ghost"
              data-testid="button-skip-forward"
            >
              <SkipForward className="w-4 h-4" />
            </Button>

            <div className="flex-1 px-4">
              <Slider
                value={[currentTime]}
                min={0}
                max={project?.duration || 30}
                step={0.1}
                onValueChange={([value]) => onTimeChange(value)}
                className="cursor-pointer"
                data-testid="slider-playhead"
              />
            </div>

            <div className="font-mono text-sm text-muted-foreground min-w-[80px] text-right" data-testid="text-timecode">
              {formatTime(currentTime)} / {formatTime(project?.duration || 30)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
