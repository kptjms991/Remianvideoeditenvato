import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { TopNav } from "@/components/editor/top-nav";
import { TemplateSidebar } from "@/components/editor/template-sidebar";
import { Canvas } from "@/components/editor/canvas";
import { PropertiesPanel } from "@/components/editor/properties-panel";
import { Timeline } from "@/components/editor/timeline";
import { TemplatePreviewModal } from "@/components/editor/template-preview-modal";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Template, Project, TimelineLayer, InsertProject } from "@shared/schema";

export default function Editor() {
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [selectedLayer, setSelectedLayer] = useState<TimelineLayer | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<Template | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [zoom, setZoom] = useState(100);
  const { toast } = useToast();

  // Auto-play functionality
  useEffect(() => {
    if (!isPlaying || !currentProject) return;
    
    const interval = setInterval(() => {
      setCurrentTime(prev => {
        const next = prev + 0.1;
        if (next >= (currentProject.duration || 30)) {
          setIsPlaying(false);
          return 0;
        }
        return next;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, currentProject]);

  const createProjectMutation = useMutation({
    mutationFn: async (data: InsertProject) => {
      return await apiRequest("POST", "/api/projects", data);
    },
    onSuccess: (project: Project) => {
      setCurrentProject(project);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Created",
        description: `${project.name} has been created successfully.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Project> }) => {
      return await apiRequest("PATCH", `/api/projects/${id}`, data);
    },
    onSuccess: (project: Project) => {
      setCurrentProject(project);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
  });

  const handleUseTemplate = (template: Template) => {
    const newProject: InsertProject = {
      name: `${template.title} - Project`,
      templateId: template.id,
      duration: template.duration || 30,
      resolution: "1920x1080",
      fps: 30,
      layers: [],
      settings: { backgroundColor: "#000000" },
    };

    createProjectMutation.mutate(newProject);
  };

  const handleSave = () => {
    if (!currentProject) {
      toast({
        title: "No Project",
        description: "Create or open a project first.",
        variant: "destructive",
      });
      return;
    }

    updateProjectMutation.mutate({
      id: currentProject.id,
      data: currentProject,
    });

    toast({
      title: "Project Saved",
      description: `${currentProject.name} has been saved.`,
    });
  };

  const handleExport = () => {
    if (!currentProject) {
      toast({
        title: "No Project",
        description: "Create or open a project first.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Export Started",
      description: "Your video is being prepared for export...",
    });

    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: "Your video has been exported successfully!",
      });
    }, 2000);
  };

  const handleLayersChange = (layers: TimelineLayer[]) => {
    if (!currentProject) return;
    
    const updatedProject = {
      ...currentProject,
      layers: layers as any,
    };
    
    setCurrentProject(updatedProject);
    
    updateProjectMutation.mutate({
      id: currentProject.id,
      data: { layers: layers as any },
    });
  };

  const handleLayerUpdate = (layer: TimelineLayer) => {
    if (!currentProject) return;
    
    const layers = currentProject.layers as TimelineLayer[];
    const updatedLayers = layers.map(l => 
      l.id === layer.id ? layer : l
    );
    
    handleLayersChange(updatedLayers);
    setSelectedLayer(layer);
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      <TopNav 
        project={currentProject}
        onSave={handleSave}
        onExport={handleExport}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <TemplateSidebar 
          onTemplateClick={(template) => setPreviewTemplate(template)}
          onUseTemplate={handleUseTemplate}
        />
        
        <div className="flex-1 flex flex-col">
          <Canvas 
            project={currentProject}
            currentTime={currentTime}
            zoom={zoom}
            onZoomChange={setZoom}
            isPlaying={isPlaying}
            onPlayPause={() => setIsPlaying(!isPlaying)}
            onTimeChange={setCurrentTime}
          />
          
          <Timeline 
            project={currentProject}
            currentTime={currentTime}
            selectedLayer={selectedLayer}
            onLayerSelect={setSelectedLayer}
            onTimeChange={setCurrentTime}
            onLayersChange={handleLayersChange}
          />
        </div>
        
        <PropertiesPanel 
          project={currentProject}
          selectedLayer={selectedLayer}
          onLayerUpdate={handleLayerUpdate}
          onProjectUpdate={(updates) => {
            if (!currentProject) return;
            const updatedProject = { ...currentProject, ...updates };
            setCurrentProject(updatedProject);
            updateProjectMutation.mutate({
              id: currentProject.id,
              data: updates,
            });
          }}
        />
      </div>

      {previewTemplate && (
        <TemplatePreviewModal
          template={previewTemplate}
          onClose={() => setPreviewTemplate(null)}
          onUseTemplate={(template) => {
            setPreviewTemplate(null);
            handleUseTemplate(template);
          }}
        />
      )}
    </div>
  );
}
